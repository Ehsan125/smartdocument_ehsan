# MyPackage

A simple example package.

## Installation

```bash
pip install smartdocument_ehsan
